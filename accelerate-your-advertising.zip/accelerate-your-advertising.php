<?php
/*
Plugin Name: Accelerate your advertising
Plugin URI: http://chinainvestor.net/Accelerate-your-advertising
Author URL: http://chinainvestor.net/
Description: Many webmaster wonder why their web site is so slowly? OK, the reason is slow advertising code from some AD union.Now,I write a wordpress plugin which can accelerate your advertising and speed your site.You can choose to make these slow advertising code be shown after your content.
Version: 3.0.2
Author: Tomas.Zhu
*/

Class moneydiy
{
	function moneydiy_aya()
	{
		$i = 0;
		$ad_code = get_option("moneydiy_ad_code");
		$ad_name = get_option("moneydiy_ad_name");
		while (list($key,$name) = each($ad_name))
		{
			$i = $i + 1;
			if (!empty($name))
			{


?>
<div id="moneydiy_myads<?php echo $i; ?>">
<?php echo stripslashes($ad_code[$key]); ?>

</div>

<script type="text/javascript">
if (document.getElementById("<?php if (!get_magic_quotes_gpc()) echo stripslashes($name); else echo $name ;?>"))
{
document.getElementById("<?php if (!get_magic_quotes_gpc()) echo stripslashes($name); else echo $name ; ?>").innerHTML = document.getElementById("moneydiy_myads<?php echo $i; ?>").innerHTML;
document.getElementById("moneydiy_myads<?php echo $i; ?>").innerHTML = "";
}
</script>

<?php		
			} 
		}
	}
	
	function moneydiy_aya_active()
	{
		add_options_page("Accelerate your advertising", 'Accelerate your advertising', 8, basename(__FILE__), array(&$this,'moneydiy_aya_setup'));
	}

	function moneydiy_aya_setup()
	{
	 	$ad_code = array();
		$ad_name = array();
		if (!user_can_access_admin_page()) wp_die(__('You do not have sufficient permissions to access this page.'));
		?>

	<div class="wrap">
	<strong><h2><u>Accelerate your advertising  - Setup</u></h2></strong>
	</div>
	<div class="wrap" id = "wpsepbl">
	<div id="dashboard-widgets-wrap">
	<div id="dashboard-widgets" class="metabox-holder">
	<div id="post-body">
	<div id="dashboard-widgets-main-content">
	<div class="postbox-container" style="width:100%;">
	<div class="postbox">
	<h3 class='hndle'><span>Please input your AD code and the div tag name related with this AD:<span></h3>
	<div class="inside" style='padding-left:15px;'>
	<br />
			
		<a href="http://moneydiy.cn">You can get support and new version from here</a><br />
		<?php
			$ad_code = get_option("moneydiy_ad_code");
			$ad_name = get_option("moneydiy_ad_name");
		?>

		<br />

		<?php

		if (!empty($ad_code) && !empty($ad_name))
		{
			$i = 0;
			while (list($key,$name) = each($ad_name))
			{
				$i = $i + 1;
				echo '<br />';
		?>
		<form name="moneydiy_submit" action="<?php  echo attribute_escape($_SERVER["REQUEST_URI"]); ?>" method = "post">
		<?php wp_nonce_field('no-hack-thanks'); ?>
		<b>Your Advertising code</b> : <br /><br /><textarea rows = "15" cols = "80" name="moneydiy_code<?php echo $i;  ?>" ><?php if (!get_magic_quotes_gpc()) echo stripslashes($ad_code[$key]); else echo $ad_code[$key]; ?></textarea><input type="hidden" name="arraynumber" value = '<?php echo "$i"; ?>'><br />
		Div tag name related with this AD:  <input type="text" name="moneydiy_name<?php echo $i;  ?>" value='<?php if (!get_magic_quotes_gpc()) echo stripslashes($ad_name[$key]); else echo $ad_name[$key]; ?>'>&nbsp&nbsp&nbsp <input type="submit" name="update" value="update">&nbsp&nbsp&nbsp <input type="submit" name="delete" value="delete"><br />
		<br />
		</form>
		<?php

			}
		} // end if
		?>		
		<form name="moneydiy_submit_add" action="<?php  echo attribute_escape($_SERVER["REQUEST_URI"]); ?>" method = "post">
		<?php wp_nonce_field('no-hack-thanks'); ?>
		<br />
		<b>New div tag name</b> :  <input type="text" name="moneydiy_name" ><br />
		<br />
		<b>New Advertising code</b>(<i><font color="Gray">Ad code related with this div tag name</font></i>) : <br /><br />
		<textarea rows = "15" cols ="80" name="moneydiy_code" >Please copy your new advertising code here....</textarea><br />
		<br /><input type="submit" name="add" value="submit"><br />
		</form>
	<br />

	</div> <?php // inside  ?>
	</div> <?php // postbox ?>
	</div> <?php // postbox-container  ?>
	</div> <?php // dashboard-widgets-main-content  ?>
	</div> <?php // post-body  ?>
	</div> <?php // dashboard-widgets  ?>
	</div> <?php // dashboard-widgets-wrap  ?>
	</div> <?php //  wrap ?>
<?php 
	}	
	function moneydiy_aya_optimize()
	{
		$ad_name = array();
		$ad_code = array();
		$ad_temp_name = array();
		$ad_temp_code = array();


		if('POST' === $_SERVER['REQUEST_METHOD'])
		check_admin_referer('no-hack-thanks');
		if ('delete' == $_REQUEST['delete'])
		{
			$monediy_isdelete = 0;
			if (isset($_REQUEST['arraynumber']) and (!empty($_REQUEST['arraynumber'])) )
			{
			if (!get_magic_quotes_gpc())
				$monediy_isdelete = addslashes(trim($_REQUEST['arraynumber'])) - 1 ;
			else
				$monediy_isdelete = trim($_REQUEST['arraynumber']) - 1;

			$ad_temp_code = get_option("moneydiy_ad_code");
			$ad_temp_name = get_option("moneydiy_ad_name");
				if (isset($ad_temp_code[$monediy_isdelete]))
				{
					unset($ad_temp_code[$monediy_isdelete]);
					$ad_temp_code = array_values($ad_temp_code);
				}
				if (isset($ad_temp_name[$monediy_isdelete]))
				{
					unset($ad_temp_name[$monediy_isdelete]);
					$ad_temp_name = array_values($ad_temp_name);
				}
				update_option("moneydiy_ad_code",$ad_temp_code);
				update_option("moneydiy_ad_name",$ad_temp_name);

			}
			return;
			
		}
		if ('update' == $_REQUEST['update'])
		{

			if (!isset($_REQUEST['arraynumber']) || (empty($_REQUEST['arraynumber'])) )
			{
				return;
			}

			$monediy_isupdate = 0;
			if (!get_magic_quotes_gpc())
				$monediy_isupdate = addslashes(trim($_REQUEST['arraynumber']));
			else
				$monediy_isupdate = trim($_REQUEST['arraynumber']);
			$temp_name = 'moneydiy_name' . $monediy_isupdate ;
			$temp_code = 'moneydiy_code' . $monediy_isupdate ;
			if (!get_magic_quotes_gpc())
			{
				$ad_name[] = addslashes(trim($_REQUEST["$temp_name"]));
				$ad_code[] = addslashes(trim($_REQUEST["$temp_code"]));
			}
			else
			{
				$ad_name[] = trim($_REQUEST["$temp_name"]);
				$ad_code[] = trim($_REQUEST["$temp_code"]);
			}

			if (empty($ad_name[0]))
			{
				return;
			}
			
			if (empty($ad_name[0]) || empty($ad_code[0]))
			{
				return;
			}
			$monediy_isupdate = 0;
			if (isset($_REQUEST['arraynumber']) and (!empty($_REQUEST['arraynumber'])) )
			{
			if (!get_magic_quotes_gpc())
				$monediy_isupdate = addslashes(trim($_REQUEST['arraynumber'])) - 1 ;
			else
				$monediy_isupdate = trim($_REQUEST['arraynumber']) - 1 ;
			$ad_temp_code = get_option("moneydiy_ad_code");
			$ad_temp_name = get_option("moneydiy_ad_name");
				if (isset($ad_temp_code[$monediy_isupdate]))
				{
					$ad_temp_code[$monediy_isupdate] = $ad_code[0];
				}
				if (isset($ad_temp_name[$monediy_isupdate]))
				{
					$ad_temp_name[$monediy_isupdate] = $ad_name[0];
				}
				update_option("moneydiy_ad_code",$ad_temp_code);
				update_option("moneydiy_ad_name",$ad_temp_name);

			}
			return;
			
		}
		if ('submit' == $_REQUEST['add'])
		{
		  if (isset($_REQUEST['moneydiy_name']) && isset($_REQUEST['moneydiy_code']))
		  {

			if (!get_magic_quotes_gpc())
			{
				$ad_name[] = addslashes(trim($_REQUEST['moneydiy_name']));
				$ad_code[] = addslashes(trim($_REQUEST['moneydiy_code']));
			}
			else
			{
				$ad_name[] = trim($_REQUEST['moneydiy_name']);
				$ad_code[] = trim($_REQUEST['moneydiy_code']);
			}
			if (empty($ad_name[0]) || empty($ad_code[0]))
			{
				return;
			}

			$ad_temp_code = get_option("moneydiy_ad_code");
			$ad_temp_name = get_option("moneydiy_ad_name");

			if (!empty($ad_temp_code[0]))
			{
				$ad_code = array_merge($ad_code,$ad_temp_code);
				$ad_code = array_values($ad_code);
			}

			if (!empty($ad_temp_name[0]))
			{
				$ad_name = array_merge($ad_name,$ad_temp_name);
				$ad_name = array_values($ad_name);
			}
			update_option("moneydiy_ad_code",$ad_code);
			update_option("moneydiy_ad_name",$ad_name);
		  }
		}
	}


}
	if (class_exists('moneydiy'))
	{
		$seo = new moneydiy();
	}
	add_action('admin_menu', array(&$seo,'moneydiy_aya_active'));
	if(false!==($safe_admin=strpos($_SERVER['REQUEST_URI'], basename(__FILE__))))add_action('admin_head', array(&$seo,'moneydiy_aya_optimize'));
	add_action('wp_footer', array(&$seo,'moneydiy_aya'));
?>