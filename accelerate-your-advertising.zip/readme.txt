=== Plugin Name: accelerate your advertising === 
Stable tag:1.5
Contributors: Tomas.Zhu
Plugin URI: http://moneydiy.cn/accelerate-your-advertising
Author URI: http://moneydiy.cn/
Donate link: http://moneydiy.cn/accelerate-your-advertising
Tags:content,keywords,slow,div,google,adsense,yahoo,posts,ajax,plugin,code,ad,advertising,accelerate
Requires at least: 2.2.3
Tested up to: 2.5.1



Copyright (c) 2008
Released under the GPL license
http://www.gnu.org/licenses/gpl.txt


== Description ==

Everybody know the value of a fast loading blog,but we found many blogs is very very slowly.
Many webmaster wonder Why are their web site is so slowly?OK, the answer is advertising code.
Now,I write a wordpress plugin which can Accelerate your advertising.
Your advertising only been shown after your content.

== Installation ==

1:Upload the plugin to the `/wp-content/plugins/` directory

2:active the plugin  'Accelerate your advertising' through the 'Plugins' menu in WordPress

== usage ==

After active the plugin, go to the 'setting' menu,you will see "Accelerate your advertising".

It is very simple to let it working,what you need to do is:

1:named  id of div in the textarea of plugin.  //for example:"myad1"

2:copy your advertising code  in the textarea of plugin.// for example:<script>xxxxxxx����</script>

Then Just use these div  id in your widget,sidebar,index.php����

for example:

<div id ='myad1'>//Which you had named in plugin

Loading����

</div >

So Plugin willfind 'myad1��,and add advertising in it.

Best,

Tomas.zhu

plugin download:
whattheywant-1-2.txt

== Screenshots == 
http://moneydiy.cn/accelerate-your-advertising

== Frequently Asked Questions ==
http://moneydiy.cn/accelerate-your-advertising

Demo:

http://moneydiy.cn/accelerate-your-advertising