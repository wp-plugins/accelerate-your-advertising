=== Plugin Name: accelerate your advertising === 
Stable tag:3.0
Contributors: Tomas.Zhu
Plugin URI: http://chinainvestor.net/accelerate-your-advertising
Author URI: http://chinainvestor.net/
Tags:content,keywords,slow,div,google,adsense,yahoo,posts,ajax,plugin,code,ad,advertising,accelerate,speed
Requires at least: 2.2.3
Tested up to: 3.0



Copyright (c) 2008
Released under the GPL license
http://www.gnu.org/licenses/gpl.txt


== Description ==
Many webmaster wonder why their web site is so slowly? OK, the reason is slow advertising code from some AD union.
Now,I write a wordpress plugin which can accelerate your advertising and speed your site.
You can choose to make these slow advertising code be shown after the appearance of the content.

== Installation ==

1:Upload the plugin to the '/wp-content/plugins/' directory

2:active the plugin  'Accelerate your advertising' through the 'Plugins' menu in WordPress

== usage ==

After active the plugin, go to the 'setting' menu,you will see "Accelerate your advertising".

It is very simple to make it working,what you need to do is:

1: Input the div tag name in which slow AD code will be placed,for example:"myad1"

2: Copy your slow advertising code in the textarea box. For example:<script>xxxxxxx......</script>

3:Then Just use these div tags in your widget,sidebar,index.php......, and so on.These slow AD will be shown at the end of your html code. Now You can add the code below in one of your widget:
----------------------------------------------------------
<div id ='myad1'>//Which you had named in plugin

Loading......

</div >
----------------------------------------------------------

Our Plugin will find the tag 'myad1', and replace "Loading......" with the advertising code related with this tag name.

Best Regards,

Tomas.zhu

plugin download:
http://chinainvestor.net/accelerate-your-advertising

== Screenshots == 
http://chinainvestor.net/accelerate-your-advertising

== Frequently Asked Questions ==
http://chinainvestor.net/accelerate-your-advertising

Demo:

http://chinainvestor.net/accelerate-your-advertising